.ossn-search {
    margin-top: 20px;
}
.ossn-search input[type='text']{
    width: 95%;
    margin: 0 auto;
    color: #000;
    border-radius: 3px;
}
